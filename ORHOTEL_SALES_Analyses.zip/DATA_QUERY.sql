-- TO query if the is a revenue increase in the hotel , segmenting by different hotels
WITH hotels as (
SELECT  *FROM dbo.['2018$']
UNION
SELECT  *FROM dbo.['2019$']
UNION
SELECT  *FROM dbo.['2020$'])
---adr is the daily rate that we have for the hotel
SELECT 
[arrival_date_year]
,[hotel]
,[Revenue] = ROUND(SUM(([stays_in_weekend_nights]+ [stays_in_week_nights])*adr),2)
FROM hotels
GROUP BY [arrival_date_year],[hotel]
Order by Revenue DESC





--WITH hotels as (
SELECT  *FROM dbo.['2018$']
UNION
SELECT  *FROM dbo.['2019$']
UNION
SELECT  *FROM dbo.['2020$'])

SELECT *
FROM hotels a
left join dbo.market_segment$ b
	on a.market_segment = b.market_segment
left join dbo.meal_cost$ c
	on a.meal = c.meal
